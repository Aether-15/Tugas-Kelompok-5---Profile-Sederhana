<?php

namespace App\Http\Controllers;

class BlogController extends Controller
{
    public function blog()
    {
        $artikel = [
            [
                'judul'=>'Belajar Laravel',
                'penulis'=>'Andi',
                'tanggal'=>'2026-01-01',
                'isi'=>'Laravel adalah framework PHP open-source yang populer,
                dirancang untuk memudahkan pengembangan aplikasi web berbasis MVC (Model-View-Controller) secara efisien, aman, dan dinamis.'
            ],
            [
                'judul'=>'Apa itu Tailwind',
                'penulis'=>'Budi',
                'tanggal'=>'2026-01-02',
                'isi'=>'TailwindCSS adalah utility-first CSS yang digunakan untuk
                membangun desain website kustom secara cepat tanpa harus meninggalkan kode HTML.'
            ],
            [
                'judul'=>'Cara Kerja View di Laravel',
                'penulis'=>'Citra',
                'tanggal'=>'2026-01-03',
                'isi'=>'Blade adalah template engine bawaan Laravel yang powerful,
                mendukung layout, section, dan komponen yang reusable.'
            ],
        ];

        return view('blog', compact('artikel'));
    }
}