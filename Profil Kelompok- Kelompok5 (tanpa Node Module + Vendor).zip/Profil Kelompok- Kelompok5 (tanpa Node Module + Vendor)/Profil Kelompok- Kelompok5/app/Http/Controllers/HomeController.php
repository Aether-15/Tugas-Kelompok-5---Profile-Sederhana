<?php

namespace App\Http\Controllers;

class HomeController extends Controller
{
    public function home()
    {
        return view('home', [
            'namaWebsite' => 'Website Profil Kelompok',
            'tagline' => 'Bersama Membangun Web',
        ]);
    }

    public function about()
    {
        $anggota = [
            ['nama'=>'Bagus Setiawan', 'nim'=>'24104410069', 'peran'=>'Ketua Kelompok','foto'=>'bagus.jpg'],
            ['nama'=>'Ivon Fadilah Kartika.D', 'nim'=>'24104410019', 'peran'=>'Anggota Kelompok','foto'=>'ivon.jpg'],
            ['nama'=>'Faizal Ramadhan', 'nim'=>'24104410033', 'peran'=>'Anggota Kelompok','foto'=>'faizal.jpg'],
            ['nama'=>'Muhammad Ardhian.J', 'nim'=>'24104410004', 'peran'=>'Anggota Kelompok','foto'=>'dian.jpg'],
            ['nama'=>'Hoki Kayana Qusyairi', 'nim'=>'24104410035', 'peran'=>'Anggota Kelompok','foto'=>'hoki.jpg'],
        ];

        return view('about', compact('anggota'));
    }

        public function contact()
    {
        $kontak = [
            'email'     => 'kelompok05@example.com',
            'alamat'    => 'Universitas Islam Balitar',
            'instagram' => '@kelompok05_dev',
            'github'    => 'github.com/kelompok05',
            'linkedin'  => 'linkedin.com/in/kelompok5',
        ];
        return view('contact', compact('kontak'));
    }
}
