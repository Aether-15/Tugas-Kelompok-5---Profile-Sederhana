<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Home</title>
    </head>
    <body>
        @extends('layouts.app')

        @section('content')

            <div class="flex flex-col items-center justify-center text-center mt-32">

                <h1 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
                    Selamat datang di Website Kelompok 5
                </h1>

                <p class="text-gray-500 mb-6">
                    {{ $tagline ?? 'Bersama Membangun Web' }}
                </p>
            </div>
        @endsection
    </body>
</html>
