<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>About</title>
    </head>
    <body>
        @extends('layouts.app')
        @section('content')
            <h2 class="text-2xl font-bold mb-6 text-center">Profil Kelompok</h2>

            <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-10">
                @foreach($anggota as $a)
                    <div class="card">
                        <div class="bg-white shadow-lg rounded-xl p-5 text-center h-[230px] flex flex-col justify-center hover:shadow-xl hover:scale-105 transition">

                            <img src="{{ asset( 'images/' . $a['foto']) }}" alt="foto"
                            class="w-35 h-35 mx-auto object-cover rounded-lg shadow-md">

                            <h3 class="text-base font-semibold">{{ $a['nama'] }}</h3>
                            <p class="text-sm text-gray-500">{{ $a['nim'] }}</p>
                            <p class="text-sm text-blue-600 mt-1">{{ $a['peran'] }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        @endsection
    </body>
</html>
