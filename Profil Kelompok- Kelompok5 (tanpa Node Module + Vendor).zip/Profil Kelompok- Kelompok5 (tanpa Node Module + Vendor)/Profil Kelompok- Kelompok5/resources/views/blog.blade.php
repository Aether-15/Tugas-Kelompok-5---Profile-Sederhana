<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Blog</title>
    </head>
    <body>
        @extends('layouts.app')

        @section('content')
            <h2 class="text-2xl font-bold mb-6 text-center">Artikel</h2>

            <div class="grid md:grid-cols-3 gap-6">
                @foreach($artikel as $a)
                    <div class="bg-white shadow-md rounded-lg p-5 hover:shadow-xl transition">
                        <h3 class="font-bold text-lg mb-2">{{ $a['judul'] }}</h3>
                        <p class="text-sm text-gray-500 mb-2">
                            {{ $a['penulis'] }} | {{ $a['tanggal'] }}
                        </p>
                        <p class="text-gray-600">{{ $a['isi'] }}</p>
                    </div>
                @endforeach
            </div>
        @endsection
    </body>
</html>
