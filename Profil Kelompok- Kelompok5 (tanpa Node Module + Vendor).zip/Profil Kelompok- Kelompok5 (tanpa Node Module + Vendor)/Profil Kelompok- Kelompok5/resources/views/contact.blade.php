<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Contact</title>
    </head>
    <body>
        @extends('layouts.app')

        @section('content')
            <h1 class="text-3xl font-bold text-gray-700 mb-8">Hubungi Kami</h1>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-white rounded-xl shadow p-6 space-y-3">
                    <h2 class="text-xl font-semibold mb-4">Informasi Kontak</h2>
                    <p>📧 {{ $kontak['email'] }}</p>
                    <p>📍 {{ $kontak['alamat'] }}</p>
                    <p>📸 {{ $kontak['instagram'] }}</p>
                    <p>💻 {{ $kontak['github'] }}</p>
                    <p>🔗 {{ $kontak['linkedin'] }}</p>
                </div>
                
                <div class="bg-white rounded-xl shadow p-6">
                    <h2 class="text-xl font-semibold mb-4">Kirim Pesan</h2>
                    <div class="space-y-4">
                        <input type="text" placeholder="Nama Anda" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <input type="email" placeholder="Email Anda" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <textarea rows="4" placeholder="Pesan..." class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"></textarea>
                        <button class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition w-full">Kirim Pesan</button>
                    </div>
                </div>
            </div>
        @endsection
    </body>
</html>
