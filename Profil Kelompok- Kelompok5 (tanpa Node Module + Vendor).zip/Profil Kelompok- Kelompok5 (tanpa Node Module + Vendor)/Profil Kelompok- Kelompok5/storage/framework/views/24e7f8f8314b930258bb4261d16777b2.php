<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Blog</title>
    </head>
    <body>
        

        <?php $__env->startSection('content'); ?>
            <h2 class="text-2xl font-bold mb-6 text-center">Artikel</h2>

            <div class="grid md:grid-cols-3 gap-6">
                <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow-md rounded-lg p-5 hover:shadow-xl transition">
                        <h3 class="font-bold text-lg mb-2"><?php echo e($a['judul']); ?></h3>
                        <p class="text-sm text-gray-500 mb-2">
                            <?php echo e($a['penulis']); ?> | <?php echo e($a['tanggal']); ?>

                        </p>
                        <p class="text-gray-600"><?php echo e($a['isi']); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coba\resources\views/blog.blade.php ENDPATH**/ ?>