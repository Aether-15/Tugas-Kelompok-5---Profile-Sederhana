<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo e($title ?? 'Profil Kelompok'); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    </head>
    <body class="flex flex-col min-h-screen bg-gray-100 text-gray-800">

        <!-- NAVBAR -->
        <nav class="bg-gray-600 text-white shadow-md">
            <div class="container mx-auto px-6 py-4 flex justify-between items-center">
                <h1 class="text-xl font-bold">Profil Kelompok 5</h1>

                <div class="space-x-6 hidden md:flex">
                    <a href="/home" class="hover:text-gray-200">Home</a>
                    <a href="/about" class="hover:text-gray-200">About</a>
                    <a href="/blog" class="hover:text-gray-200">Blog</a>
                    <a href="/contact" class="hover:text-gray-200">Contact</a>
                </div>
            </div>
        </nav>

        <!-- CONTENT -->
        <main class="container mx-auto px-6 py-8 flex-grow">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- FOOTER -->
        <footer class="bg-gray-600 text-white shadow-md text-center py-4 mt-10">
            © 2026 Kelompok 5 Pemograman Web Lanjut
        </footer>
    </body>
</html><?php /**PATH C:\laragon\www\Profil Kelompok- Kelompok5\resources\views/layouts/app.blade.php ENDPATH**/ ?>