<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>About</title>
    </head>
    <body>
        
        <?php $__env->startSection('content'); ?>
            <h2 class="text-2xl font-bold mb-6 text-center">Profil Kelompok</h2>

            <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-10">
                <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="bg-white shadow-lg rounded-xl p-5 text-center h-[230px] flex flex-col justify-center hover:shadow-xl hover:scale-105 transition">

                            <img src="<?php echo e(asset( 'images/' . $a['foto'])); ?>" alt="foto"
                            class="w-35 h-35 mx-auto object-cover rounded-lg shadow-md">

                            <h3 class="text-base font-semibold"><?php echo e($a['nama']); ?></h3>
                            <p class="text-sm text-gray-500"><?php echo e($a['nim']); ?></p>
                            <p class="text-sm text-blue-600 mt-1"><?php echo e($a['peran']); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Profil Kelompok- Kelompok5\resources\views/about.blade.php ENDPATH**/ ?>