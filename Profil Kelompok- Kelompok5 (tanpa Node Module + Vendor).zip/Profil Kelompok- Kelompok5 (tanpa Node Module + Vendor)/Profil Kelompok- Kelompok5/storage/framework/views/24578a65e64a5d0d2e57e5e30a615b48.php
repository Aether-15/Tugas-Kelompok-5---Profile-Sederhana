<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Home</title>
    </head>
    <body>
        

        <?php $__env->startSection('content'); ?>

            <div class="flex flex-col items-center justify-center text-center mt-32">

                <h1 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
                    Selamat datang di Website Kelompok 5
                </h1>

                <p class="text-gray-500 mb-6">
                    <?php echo e($tagline ?? 'Bersama Membangun Web'); ?>

                </p>

                
            </div>
        <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Profil Kelompok- Kelompok5\resources\views/home.blade.php ENDPATH**/ ?>